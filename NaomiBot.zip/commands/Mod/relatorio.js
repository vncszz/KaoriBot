const { SlashCommandBuilder, EmbedBuilder, TextInputStyle, ModalBuilder, TextInputBuilder, ActionRowBuilder } = require("discord.js");
const bot = require("../../bot.json")

module.exports = {
    data: new SlashCommandBuilder()
        .setName("criar-relatorio")
        .setDescription("Faça um relatorio geral sobre seu andamento."),
    /**
     * 
     * @param {interaction} interaction 
     */

    async execute(interaction) {

        const { client, member } = interaction;
        //const cargo = "1093561894503186565";

        if (!interaction.member.permissions.has(bot.config.ownerId)) {
            interaction.reply({ content: `você não possui permissão para isso.`, ephemeral: true });
        } else {

            const modal = new ModalBuilder()
                .setCustomId('modalRelatorio')
                .setTitle('Relatório Staff 🏷️')

            const relatorioDesc = new TextInputBuilder()
                .setCustomId('relatórioDesc')
                .setLabel('Envie seu relatório aqui.')
                .setStyle(TextInputStyle.Paragraph)

            const firstActionRow = new ActionRowBuilder().addComponents(relatorioDesc)

            modal.addComponents(firstActionRow)

            await interaction.showModal(modal);
        }

        client.once('interactionCreate', async interaction => {
            if (!interaction.isModalSubmit()) return;

            if (interaction.customId === 'modalRelatorio') {

                const desc = interaction.fields.getTextInputValue('relatórioDesc');
                const canal = interaction.guild.channels.cache.get('1097664054232887356');

                const topRoles = member.roles.cache
                    .sort((a, b, c) => b.position - a.position)
                    .map(role => role)
                    .slice(0, 2)

                const embed = new EmbedBuilder()
                    .setColor("#FCB6F6")
                    .setTitle("Novo Relatório")
                    .setDescription(`${desc}`)
                    .setFooter({ text: `ID: ${interaction.user.id}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
                    .addFields({ name: `Moderador:`, value: `${interaction.user}`, inline: true })
                    .addFields({ name: `Cargos:`, value: `${topRoles}`, inline: true })
                    .setTimestamp(new Date);

                interaction.reply({ content: 'Seu relatório foi enviado e será analisado pelos superiores.', ephemeral: true }).catch(err => {
                    console.log(err)
                })

                await canal.send({ embeds: [embed] });

            }

        })

    }
}