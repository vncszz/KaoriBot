# Naomi-Bot #
<figure>
  <img src="https://cdn.discordapp.com/avatars/931522649442639872/2d6eb7b2c80523a960e378ff0bc8ec27.webp?size=2048" alt="Meu Perfil" height="100" width="100">
</figure>

**The Utils commands, ticket and partner command** 💖

*©Copyright, Naomi Bot - All Rights Reserved™ - 2023.*

