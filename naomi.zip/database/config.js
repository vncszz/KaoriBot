require("dotenv").config();

module.exports = {
    TOKEN: process.env.TOKEN || "YOUR_TOKEN",  // your bot token
    MONGO_URI: process.env.MONGO_URI || "YOUR_MONGO_URI", // your mongo uri
}